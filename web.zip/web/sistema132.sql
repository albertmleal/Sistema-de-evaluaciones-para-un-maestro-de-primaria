-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-02-2020 a las 03:56:06
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema132`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'admin', '123456');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('558922894c453', '558922895ea0a'),
('558922899ccaa', '55892289aa7cf'),
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('5c9923ca9144f', '5c9923ca91615'),
('5c9ae2391cf78', '5c9ae2391d1cf'),
('5c9ae2391d8d3', '5c9ae2391d9f9'),
('5c9ae61ae9a95', '5c9ae61ae9c70'),
('5c9ae61aea49f', '5c9ae61aea5b8'),
('5ca9421ee097e', '5ca9421ee1c64'),
('5ca9421ee2e14', '5ca9421ee3222'),
('5ca9421ee3878', '5ca9421ee39ea'),
('5ca9421ee3e73', '5ca9421ee3f82'),
('5ca9421ee4c98', '5ca9421ee4e65');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('5c9ae1c30f469', 'José Alberto Madrigal Leal', 'jose.mleal@alumnos.udg.mx', 'Tarea', 'Ya se la mande profe.', '2019-03-27', '03:36:51am'),
('5ca945bb8da13', 'camacho', 'hola@gmail.com', 'extraordinario', '100', '2019-04-07', '02:35:07am');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('admin', '5c9ae20c1a206', 2, 2, 2, 0, '2019-03-27 02:35:04'),
('luis_sexii@live.com.mx', '5c9ae20c1a206', 2, 2, 2, 0, '2019-03-27 02:47:24'),
('admin', '5c9ae5f3ece88', 1, 2, 1, 1, '2019-03-27 02:50:16'),
('admin', '5ca94158b5bf4', 5, 5, 5, 0, '2019-04-07 00:14:20'),
('hola@gmail.com', '5ca94158b5bf4', 4, 5, 4, 1, '2019-04-07 00:22:23'),
('hola@gmail.com', '5c9ae5f3ece88', 2, 2, 2, 0, '2019-04-07 00:23:30'),
('mario@gmail.com', '5ca94158b5bf4', 5, 5, 5, 0, '2020-02-20 02:53:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('5c9ae2391cf78', '2', '5c9ae2391d1cf'),
('5c9ae2391cf78', '222', '5c9ae2391d212'),
('5c9ae2391cf78', '11', '5c9ae2391d255'),
('5c9ae2391cf78', '22', '5c9ae2391d29a'),
('5c9ae2391d8d3', '4', '5c9ae2391d9f9'),
('5c9ae2391d8d3', '2', '5c9ae2391da3d'),
('5c9ae2391d8d3', '2', '5c9ae2391da82'),
('5c9ae2391d8d3', '2', '5c9ae2391dac6'),
('5c9ae61ae9a95', '1', '5c9ae61ae9c70'),
('5c9ae61ae9a95', '2', '5c9ae61ae9cb5'),
('5c9ae61ae9a95', '3', '5c9ae61ae9d16'),
('5c9ae61ae9a95', '4', '5c9ae61ae9d71'),
('5c9ae61aea49f', '1', '5c9ae61aea5b8'),
('5c9ae61aea49f', '2', '5c9ae61aea5fc'),
('5c9ae61aea49f', '3', '5c9ae61aea640'),
('5c9ae61aea49f', '4', '5c9ae61aea684'),
('5ca9421ee097e', '46', '5ca9421ee1c64'),
('5ca9421ee097e', '1', '5ca9421ee1caa'),
('5ca9421ee097e', '1', '5ca9421ee1cef'),
('5ca9421ee097e', '1', '5ca9421ee1d3e'),
('5ca9421ee2e14', '2', '5ca9421ee31dc'),
('5ca9421ee2e14', '20', '5ca9421ee3222'),
('5ca9421ee2e14', '2', '5ca9421ee326a'),
('5ca9421ee2e14', '2', '5ca9421ee32af'),
('5ca9421ee3878', '3', '5ca9421ee3990'),
('5ca9421ee3878', '2', '5ca9421ee39ea'),
('5ca9421ee3878', '4', '5ca9421ee3a35'),
('5ca9421ee3878', '5', '5ca9421ee3a7a'),
('5ca9421ee3e73', '0', '5ca9421ee3f82'),
('5ca9421ee3e73', '2', '5ca9421ee3fc7'),
('5ca9421ee3e73', '2', '5ca9421ee400a'),
('5ca9421ee3e73', '2', '5ca9421ee404e'),
('5ca9421ee4c98', '2', '5ca9421ee4d99'),
('5ca9421ee4c98', '22', '5ca9421ee4dde'),
('5ca9421ee4c98', '2', '5ca9421ee4e22'),
('5ca9421ee4c98', '0', '5ca9421ee4e65');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('5c9ae20c1a206', '5c9ae2391cf78', '1+1', 4, 1),
('5c9ae20c1a206', '5c9ae2391d8d3', '2+2', 4, 2),
('5c9ae5f3ece88', '5c9ae61ae9a95', 'pablito', 4, 1),
('5c9ae5f3ece88', '5c9ae61aea49f', 'clavito', 4, 2),
('5ca94158b5bf4', '5ca9421ee097e', '12 * 4', 4, 1),
('5ca94158b5bf4', '5ca9421ee2e14', '10 + 10', 4, 2),
('5ca94158b5bf4', '5ca9421ee3878', '1+ 1', 4, 3),
('5ca94158b5bf4', '5ca9421ee3e73', '5  - 5', 4, 4),
('5ca94158b5bf4', '5ca9421ee4c98', '0 + 0', 4, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('5c9ae20c1a206', 'Extraordinario', 1, 0, 2, 0, '', '', '2019-03-27 02:32:07'),
('5c9ae5f3ece88', 'Español', 1, 0, 2, 0, '', '', '2019-03-27 02:48:47'),
('5ca94158b5bf4', 'Matematicas', 1, 0, 5, 0, '', '', '2019-04-07 00:10:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('luis_sexii@live.com.mx', 2, '2019-03-27 02:47:24'),
('hola@gmail.com', 6, '2019-04-07 00:23:30'),
('mario@gmail.com', 5, '2020-02-20 02:53:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Camacho', 'M', 'cucosta', 'hola@gmail.com', 293500, '60ddb1acfc7b9f7458a0a2be1f65d01c'),
('Ale', 'M', 'cucosta', 'luis@gmail.com', 3222065843, 'c3dbaaca8e28e7e9082e0f362ad07a58'),
('Luis Alejandro Espinosa Langarica', 'M', 'Centro Universitario de la Costa', 'luis_sexii@live.com.mx', 3222065843, '7742f8eaf28b743fde180a4969dbcf49'),
('Mario', 'M', 'cuc', 'mario@gmail.com', 3222942352, '265011d9bc9a01daa5193632c5950520'),
('Jose Madrigal', 'M', 'cucosta', 'ten01.net@yahoo.com', 0, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
