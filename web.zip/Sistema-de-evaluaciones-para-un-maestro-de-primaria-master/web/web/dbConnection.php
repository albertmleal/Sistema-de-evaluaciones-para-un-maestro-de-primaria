
<?php
$con= new mysqli('localhost','root','','sistema132')or die("Could not connect to mysql".mysqli_error($con));

?>


<!-- conexion para uns servidor web 
<?php
//all the variables defined here are accessible in all the files that include this one
//$con= new mysqli('mysql.webcindario.com','sistema132','ctuohVZq4u6','sistema132')or die("Could not connect to mysql".mysqli_error($con)); 

?>

